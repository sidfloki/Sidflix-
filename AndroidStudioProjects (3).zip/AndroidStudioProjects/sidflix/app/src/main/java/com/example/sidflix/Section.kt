package com.example.sidflix

data class Section(val name: String, val fileName: String)