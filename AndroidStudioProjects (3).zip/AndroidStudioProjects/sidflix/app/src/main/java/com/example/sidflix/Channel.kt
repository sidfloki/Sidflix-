package com.example.sidflix

data class Channel(val name: String, val url: String)