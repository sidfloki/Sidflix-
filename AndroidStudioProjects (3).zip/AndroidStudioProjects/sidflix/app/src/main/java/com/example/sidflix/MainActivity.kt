package com.example.sidflix

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.sidflix.databinding.ActivityMainBinding
import java.io.BufferedReader
import java.io.InputStreamReader

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var player: ExoPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val sections = listOf(
            Section("France TV", "channels_france.m3u"),
            Section("Algrein TV", "channels_dz.m3u"),
            Section("Bien Sport TV Arabe", "bein_sport_ar.m3u"),
            Section("Bein Sport TV France", "bein_sport_fr.m3u"),
            Section("Films Arabe TV", "films_arabe.m3u"),
            Section("Movies", "movies.m3u")
        )

        binding.sectionsRecyclerView.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        binding.sectionsRecyclerView.adapter = SectionAdapter(sections) { section ->
            loadChannels(section.fileName)
        }

        loadChannels(sections[0].fileName)
    }

    private fun loadChannels(fileName: String) {
        val channels = mutableListOf<Channel>()
        val inputStream = assets.open(fileName)
        val reader = BufferedReader(InputStreamReader(inputStream))
        var line: String?
        var channelName: String? = null

        while (reader.readLine().also { line = it } != null) {
            if (line!!.startsWith("#EXTINF")) {
                channelName = line!!.substringAfter(",")
            } else if (line!!.startsWith("http")) {
                if (channelName != null) {
                    channels.add(Channel(channelName, line!!))
                    channelName = null
                }
            }
        }

        binding.itemsRecyclerView.layoutManager = LinearLayoutManager(this)
        binding.itemsRecyclerView.adapter = ChannelAdapter(channels) { channel ->
            playChannel(channel.url)
        }
    }

    private fun initializePlayer() {
        player = ExoPlayer.Builder(this).build()
        binding.playerView.player = player
    }

    private fun playChannel(url: String) {
        player?.let {
            val mediaItem = MediaItem.fromUri(url)
            it.setMediaItem(mediaItem)
            it.prepare()
            it.play()
        }
    }

    override fun onStart() {
        super.onStart()
        initializePlayer()
    }

    override fun onStop() {
        super.onStop()
        releasePlayer()
    }

    private fun releasePlayer() {
        player?.release()
        player = null
    }
}